package com.example.homesecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class homesecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(homesecurityApplication.class, args);
    }

}
